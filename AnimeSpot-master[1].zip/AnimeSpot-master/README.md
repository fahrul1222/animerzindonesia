# AnimeSpot
Anime Information. (Retrofit 2 + SQLite + MVP Architecture)<br/>
<h3>Feature</h3>
* Showing airing anime in this season<br/>
* Showing upcoming anime in next season<br/>
* Showing top Anime<br/>
* Save anime favorites<br/>
* Showing today and tomorrow anime schedule<br/>
* Search anime<br/>
* Anime details<br/>
<h3>Screenshots</h3>
<img src="https://image.ibb.co/bz09D9/Screen_Shot_2018_08_15_at_00_23_00.png" height='300px' widht='150px'><br/>
<img src="https://image.ibb.co/ja6ufp/Screen_Shot_2018_08_15_at_00_25_22.png" height='300px' widht='150px'><br/>
<img src="https://image.ibb.co/dwNpD9/Screen_Shot_2018_08_15_at_00_25_41.png" height='300px' widht='150px'><br/>
<img src="https://image.ibb.co/nsrS0p/Screen_Shot_2018_08_15_at_00_25_53.png" height='300px' widht='150px'><br/>
<img src="https://image.ibb.co/kohNY9/Screen_Shot_2018_08_15_at_00_26_03.png" height='300px' widht='150px'><br/>
<img src="https://image.ibb.co/iRvy6U/Screen_Shot_2018_08_15_at_00_26_18.png" height='300px' widht='150px'><br/>
<img src="https://image.ibb.co/cwLy6U/Screen_Shot_2018_08_15_at_00_26_56.png" height='300px' widht='150px'><br/>
<img src="https://image.ibb.co/k6J70p/Screen_Shot_2018_08_15_at_00_27_14.png" height='300px' widht='150px'>
<h4>Used Libarary:</h4>
Material Toast : (https://github.com/valdesekamdem/MaterialDesign-Toast)<br/>
Material Dialog : (https://github.com/afollestad/material-dialogs)<br/>
Bottom Navigation : (https://github.com/aurelhubert/ahbottomnavigation)<br/>
Retrofit : (http://square.github.io/retrofit)<br/>
Glide : (https://github.com/bumptech/glide)<br/>
Google Progress Bar : (https://github.com/jpardogo/GoogleProgressBar)<br/>
Unofficial myanimelist API : (https://github.com/jikan-me/jikan)
