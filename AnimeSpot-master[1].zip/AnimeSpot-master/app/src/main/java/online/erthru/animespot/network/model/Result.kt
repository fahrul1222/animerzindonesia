package online.erthru.animespot.network.model

data class Result(

        var mal_id:Int?,
        var image_url:String?,
        var title:String?,
        var description:String?,
        var score:Double?

)