package online.erthru.animespot.network.model

data class Staff (

        var image_url: String?,
        var name:String?,
        var role:String?

)