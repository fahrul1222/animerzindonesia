package online.erthru.animespot.network.model

data class Day(

        var mal_id:Int?,
        var title:String?,
        var image_url:String?,
        var airing_start:String?

)