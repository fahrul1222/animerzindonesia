package online.erthru.animespot.network.model

data class Top(

        var mal_id:Int?,
        var image_url:String?,
        var title:String?,
        var type:String?,
        var members:Int?,
        var score:Double?

)