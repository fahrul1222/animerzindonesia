package online.erthru.animespot.network.model

data class Producer (

        var name:String?

)