package online.erthru.animespot.local.model

data class Favorite(

        var favorites_anime_id:Int?,
        var favorites_anime_name:String?,
        var favorites_anime_image:String?

)