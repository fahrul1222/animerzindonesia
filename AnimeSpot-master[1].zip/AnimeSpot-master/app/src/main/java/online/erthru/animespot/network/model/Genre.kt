package online.erthru.animespot.network.model

data class Genre(

        var name:String?

)